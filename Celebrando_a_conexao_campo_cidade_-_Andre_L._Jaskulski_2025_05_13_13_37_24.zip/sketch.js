let campo = [];
let cidade = [];
let produtos = [];
let pessoas = [];
let festaAtiva = false;

function setup() {
  createCanvas(800, 500);
  
  // Criar elementos do campo
  for (let i = 0; i < 5; i++) {
    campo.push(new Fazenda(random(50, 350), random(100, 400)));
  }
  
  // Criar elementos da cidade
  for (let i = 0; i < 8; i++) {
    cidade.push(new Predio(random(450, 750), random(50, 400)));
  }
  
  // Criar caminhões de transporte
  for (let i = 0; i < 3; i++) {
    produtos.push(new Caminhao(random(width)));
  }
}

function draw() {
  background(135, 206, 235); // Céu azul
  
  // Desenhar campo (lado esquerdo)
  fill(34, 139, 34);
  rect(0, height/2, width/2, height/2);
  
  // Desenhar cidade (lado direito)
  fill(169, 169, 169);
  rect(width/2, height/2, width/2, height/2);
  
  // Atualizar e mostrar elementos
  for (let f of campo) {
    f.update();
    f.show();
  }
  
  for (let p of cidade) {
    p.update();
    p.show();
  }
  
  for (let c of produtos) {
    c.update();
    c.show();
    
    // Transportar produtos entre campo e cidade
    if (c.x > width) {
      c.x = 0;
      c.carregado = !c.carregado;
    }
  }
  
  // Mostrar conexões
  if (festaAtiva) {
    mostrarConexoes();
    mostrarFogos();
    
    // Mostrar pessoas festejando
    for (let p of pessoas) {
      p.update();
      p.show();
    }
  }
  
  // Legenda
  fill(255);
  textSize(16);
  text("CAMPO", 50, 30);
  text("CIDADE", width - 100, 30);
  textSize(12);
  text("Clique para começar a festa!", width/2 - 80, height - 20);
}

function mousePressed() {
  festaAtiva = !festaAtiva;
  
  // Adicionar pessoas festejando
  if (festaAtiva) {
    for (let i = 0; i < 20; i++) {
      pessoas.push(new Pessoa(random(width), random(height/2, height)));
    }
  } else {
    pessoas = [];
  }
}

function mostrarConexoes() {
  stroke(255, 215, 0, 150);
  strokeWeight(2);
  
  // Linhas conectando campo e cidade
  for (let f of campo) {
    for (let p of cidade) {
      line(f.x, f.y, p.x, p.y);
    }
  }
}

function mostrarFogos() {
  for (let i = 0; i < 5; i++) {
    let x = random(width);
    let y = random(height/3);
    let tamanho = random(10, 30);
    
    fill(random(255), random(255), random(255), 200);
    noStroke();
    ellipse(x, y, tamanho);
  }
}

// Classes dos objetos
class Fazenda {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = random(30, 60);
    this.cor = color(0, random(100, 200), 0);
  }
  
  update() {
    // Animação de crescimento
    this.tamanho = 50 + sin(frameCount * 0.05) * 10;
  }
  
  show() {
    fill(this.cor);
    rect(this.x, this.y, this.tamanho, this.tamanho);
    
    // Detalhes da fazenda
    fill(139, 69, 19);
    rect(this.x + 10, this.y + 10, 15, 20); // Casa
  }
}

class Predio {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.altura = random(40, 100);
    this.largura = random(20, 40);
    this.janelas = [];
    
    // Criar janelas
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        this.janelas.push({
          x: this.x + 5 + i * (this.largura/3),
          y: this.y + 5 + j * (this.altura/3),
          acesa: random() > 0.5
        });
      }
    }
  }
  
  update() {
    // Piscar janelas
    if (frameCount % 10 == 0) {
      for (let j of this.janelas) {
        j.acesa = random() > 0.3;
      }
    }
  }
  
  show() {
    fill(70, 70, 80);
    rect(this.x, this.y, this.largura, this.altura);
    
    // Desenhar janelas (versão corrigida)
    for (let j of this.janelas) {
      if (j.acesa) {
        fill(255, 255, 100); // Amarelo para janelas acesas
      } else {
        fill(40); // Cinza escuro para janelas apagadas
      }
      rect(j.x, j.y, 5, 5);
    }
  }
}

class Caminhao {
  constructor(x) {
    this.x = x;
    this.y = height/2 + 20;
    this.vel = 2;
    this.carregado = false;
  }
  
  update() {
    this.x += this.vel;
  }
  
  show() {
    if (this.carregado) {
      fill(200, 150, 0); // Laranja quando carregado
    } else {
      fill(200, 0, 0); // Vermelho quando vazio
    }
    rect(this.x, this.y, 40, 20);
    fill(0);
    rect(this.x + 30, this.y + 5, 10, 10); // Cabine
  }
}

class Pessoa {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velX = random(-1, 1);
    this.velY = random(-1, 1);
    this.cor = color(random(255), random(255), random(255));
  }
  
  update() {
    this.x += this.velX;
    this.y += this.velY;
    
    // Manter dentro da tela
    if (this.x < 0 || this.x > width) this.velX *= -1;
    if (this.y < height/2 || this.y > height) this.velY *= -1;
  }
  
  show() {
    fill(this.cor);
    ellipse(this.x, this.y, 10, 15); // Corpo
    ellipse(this.x, this.y - 10, 8); // Cabeça
  }
}